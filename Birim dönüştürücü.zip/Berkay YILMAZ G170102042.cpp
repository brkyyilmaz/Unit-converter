#include<iostream>
using namespace std;
int main()
{
	
    int secim,sec,secme,secen,secenek,secimler;
    double mm,cm,dm,m,dam,hm,km,cel,fah,kel,ran,kg,hg,dag,g,gr,lib,sl,sn,dk,saat,newt,knewt,mnewt,kw,w,mW,hp;
    setlocale(LC_ALL, "Turkish"); 
	cout<<"******B�R�M D�N��T�RME PROGRAMI******\n\n";
	cout<<"D�n��t�rmek istei�iniz birimi se�iniz ; \n1-Uzunluk D�n���m�\n2-S�cakl�k D�n���m�\n3-K�tle D�n���m�\n4-Zaman D�n���m�\n5-Kuvvet D�n���m�\n6-G�� D�n���m�\n";
	while(secim<1 || secim>6)
	{
		cout<<"D�N��T�RMEK �STED���N�Z B�R�M ���N 1-6 ARASI SE��M YAPINIZ\n";
		cin>>secim;
	}
	if (secim==1)
	{
		cout<<"1-Milimetre D�n���m�\n2-Santimetre D�n���m�\n3-Desimetre D�n���m�\n4-Metre D�n���m�\n5-Dekametre D�n���m�\n6-Hektometre D�n���m�\n7-Kilometre D�n���m�\n";
		while(sec<1 || sec>7);
		
		
			cout<<"L�tfen 1 ile 7 aras�ndaki se�eneklerden birisini se�iniz=\n\n"<<endl;
			cin>>sec;
	    
		 
		
		if(sec==1)
		{
			cout<<"D�n��t�rmek �stedi�iniz Milimetre De�erini Giriniz=";
			cin>>mm;
			cm=mm/10;
			cout<<"Milimetreyi Santimetreye D�n��t�rme="<<cm<<endl<<endl;
			dm=mm/100;
			cout<<"Milimetreyi Desimetreye D�n��t�rme="<<dm<<endl<<endl;
			m=mm/1000;
			cout<<"Milimetreyi metreye D�n��t�rme="<<m<<endl<<endl;
			dam=mm/10000;
			cout<<"Milimetreyi Dekametreye D�n��t�rme="<<dam<<endl<<endl;
			hm=mm/100000;
			cout<<"Milimetreyi Hektometreye D�n��t�rme="<<hm<<endl<<endl;
			km=mm/1000000;
			cout<<"Milimetreyi Kilometreye D�n��t�rme="<<km<<endl<<endl;
        }
		else if(sec==2)
		{
			cout<<"D�n��t�rmek �stedi�iniz Santimetre De�erini Giriniz=";
			cin>>cm;
			mm=cm*10;
			cout<<"Santimetreyi Milimetreye D�n��t�rme="<<mm<<endl<<endl;
			dm=cm/10;
			cout<<"Santimetreyi Desimetre D�n��t�rme="<<dm<<endl<<endl;
			m=cm/100;
			cout<<"Santimetreyi metreye D�n��t�rme="<<m<<endl<<endl;
			dam=cm/1000;
			cout<<"Santimetreyi Dekametreye D�n��t�rme="<<dam<<endl<<endl;
			hm=cm/10000;
			cout<<"Santimetreyi Hektometreye D�n��t�rme="<<hm<<endl<<endl;
			km=cm/100000;
			cout<<"Santimetreyi Kilometreye D�n��t�rme="<<km<<endl<<endl;
		}
		else if(sec==3)
		{
			cout<<"D�n��t�rmek �stedi�iniz Desimetre De�erini Giriniz=";
			cin>>dm;
			mm=dm*100;
			cout<<"Desimetreyi Milimetreye D�n��t�rme="<<mm<<endl<<endl;
			cm=dm*10;
			cout<<"Desimetreyi Santimetreye D�n��t�rme="<<cm<<endl<<endl;
			m=dm/10;
			cout<<"Desimetreyi metreye D�n��t�rme="<<m<<endl<<endl;
			dam=dm/100;
			cout<<"Desimetreyi Dekametreye D�n��t�rme="<<dam<<endl<<endl;
			hm=dm/1000;
			cout<<"Desimetreyi Hektometreye D�n��t�rme="<<hm<<endl<<endl;
			km=dm/10000;
			cout<<"Desimetreyi Kilometreye D�n��t�rme="<<km<<endl<<endl;
		}
			else if(sec==4)
		{
			cout<<"D�n��t�rmek �stedi�iniz Metre De�erini Giriniz=";
			cin>>m;
			mm=m*1000;
			cout<<"Metreyi Milimetreye D�n��t�rme="<<mm<<endl<<endl;
			cm=m*100;
			cout<<"Metreyi Santimetreye D�n��t�rme="<<cm<<endl<<endl;
			dm=m*10;
			cout<<"Metreyi Dekametreyi D�n��t�rme="<<dm<<endl<<endl;
			dam=m/10;
			cout<<"Metreyi Dekametreye D�n��t�rme="<<dam<<endl<<endl;
			hm=m/100;
			cout<<"Metreyi Hektometreye D�n��t�rme="<<hm<<endl<<endl;
			km=m/1000;
			cout<<"Metreyi Kilometreye D�n��t�rme="<<km<<endl<<endl;
		}
		else if(sec==5)
		{
			cout<<"D�n��t�rmek �stedi�iniz Dekametre De�erini Giriniz=";
			cin>>dam;
			mm=dam*10000;
			cout<<"Dekametreyi Milimetreye D�n��t�rme="<<mm<<endl<<endl;
			cm=dam*1000;
			cout<<"Dekametreyi Santimetreye D�n��t�rme="<<cm<<endl<<endl;
			m=dam*10;
			cout<<"Dekametreyi metreye D�n��t�rme="<<m<<endl<<endl;
			dm=dam*100;
			cout<<"Dekametreyi Desimetreye D�n��t�rme="<<dm<<endl<<endl;
			hm=dam/10;
			cout<<"Dekametreyi Hektometreye D�n��t�rme="<<hm<<endl<<endl;
			km=dam/100;
			cout<<"Dekametreyi Kilometreye D�n��t�rme="<<km<<endl<<endl;
		}
		else if(sec==6)
		{
			cout<<"D�n��t�rmek �stedi�iniz Hektometre De�erini Giriniz=";
			cin>>hm;
			mm=hm*100000;
			cout<<"Hektometreyi Milimetreye D�n��t�rme="<<mm<<endl<<endl;
			cm=hm*10000;
			cout<<"Hektometreyi Santimetreye D�n��t�rme="<<cm<<endl<<endl;
			m=hm*100;
			cout<<"Hektometreyi metreye D�n��t�rme="<<m<<endl<<endl;
			dam=hm*10;
			cout<<"Hektometreyi Dekametreye D�n��t�rme="<<dam<<endl<<endl;
			dm=hm*10000;
			cout<<"Hektometreyi Desimetreye D�n��t�rme="<<dm<<endl<<endl;
			km=hm/10;
			cout<<"Hektometreyi Kilometreye D�n��t�rme="<<km<<endl<<endl;
		}
		else if(sec==7)
		{
			cout<<"D�n��t�rmek �stedi�iniz Kilometre De�erini Giriniz=";
			cin>>km;
			mm=km*1000000;
			cout<<"Kilometreyi Milimetreye D�n��t�rme="<<mm<<endl<<endl;
			cm=km*100000;
			cout<<"Kilometreyi Santimetreye D�n��t�rme="<<cm<<endl<<endl;
			m=km*1000;
			cout<<"Kilometreyi metreye D�n��t�rme="<<m<<endl<<endl;
			dam=km*100;
			cout<<"Kilometreyi Dekametreye D�n��t�rme="<<dam<<endl<<endl;
			hm=km*10;
			cout<<"Kilometreyi Hektometreye D�n��t�rme="<<hm<<endl<<endl;
			dm=km*10000;
			cout<<"Kilometreyi Desimetreye D�n��t�rme="<<dm<<endl<<endl;
		
	    }
    }
	else if (secim==2)
	{
		cout<<"1-Celcius D�n���m�\n2-Fahrenheit D�n���m�\n3-Kelvin D�n���m�\n4-Rankine D�n���m�\n";
		while(secme<1 || secme>4)
		{
			cout<<"L�tfen 1 ile 4 aras�ndaki se�eneklerden birisini se�iniz=\n\n"<<endl;
			cin>>secme;
		}
		
		if(secme==1)
		{
			cout<<"D�n��t�rmek �stedi�iniz Celcius De�erini Giriniz=\n\n";
			cin>>cel;
			fah=(cel*1.8)+32;
			cout<<"Celciusu Fahrenheite �evirme=\n\n"<<fah<<endl<<endl;
			kel=cel+273.15;
			cout<<"Celciusu Kelvine �evirme=\n\n"<<kel<<endl<<endl;
			ran=(cel*1.8)+491.67;
			cout<<"Celciusu Rankineye �evirme=\n\n"<<ran<<endl<<endl;
			
		}
		else if(secme==2)
		{
			cout<<"D�n��t�rmek �stedi�iniz Fahrenheit De�erini Giriniz=\n\n";
			cin>>fah;
			cel=(fah-32)/1.8;
			cout<<"Fahrenheiti Celciusa �evirme=\n\n"<<cel<<endl<<endl;
			kel=((fah-32)/1.8)+273.15;
			cout<<"Fahrenheiti Kelvine �evirme=\n\n"<<kel<<endl<<endl;
			ran=(fah-32)+491.67;
			cout<<"Fahrenheiti Rankineye �evirme=\n\n"<<ran<<endl<<endl;
			
		}
		else if(secme==3)
		{
			cout<<"D�n��t�rmek �stedi�iniz Kelvin De�erini Giriniz=\n\n";
			cin>>kel;
			fah=((kel-273.15)*1.8)+32;
			cout<<"Kelvini Fahrenheite �evirme=\n\n"<<fah<<endl<<endl;
			cel=kel-273.15;
			cout<<"Kelvini Celciusa �evirme=\n\n"<<cel<<endl<<endl;
			ran=((kel-273.15)*1.8)+491.67;
			cout<<"Kelvini Rankineye �evirme=\n\n"<<ran<<endl<<endl;
			
		}
	    else if(secme==4)
		{
			cout<<"D�n��t�rmek �stedi�iniz Rankine De�erini Giriniz=\n\n";
			cin>>ran;
			fah=(ran-491.67)+32;
			cout<<"Rankineyi Fahrenheite �evirme=\n\n"<<fah<<endl<<endl;
			cel=(ran-491.67)/1.8;
			cout<<"Rankineyi Celciusa �evirme=\n\n"<<cel<<endl<<endl;
			kel=((ran-491.67)/1.8)+273.15;
			cout<<"Rankineyi Kelvine �evirme=\n\n"<<kel<<endl<<endl;
			
		}
		
	}
    else if (secim==3)
	{
		cout<<"1-Kilogram D�n���m�\n2-Hektogram D�n���m�\n3-Dekagram D�n���m�\n4-Gram D�n���m�\n5-Libre D�n���m�\n";
		while(secen<1 || secen>5)
		{
			cout<<"l�tfen 1 ile 5 aras�ndaki se�eneklerden birisini se�iniz=\n";
			cin>>secen;
		}
	
		if(secen==1)
		{
			cout<<"D�n��t�rmek �stedi�iniz Kilogram De�erini Giriniz=\n\n";
			cin>>kg;
			gr=(kg*1000);
			cout<<"Kilogram� Grama �evirme=\n\n"<<gr<<endl<<endl;
			dag=(kg*100);
			cout<<"Kilogram� Dekagrama �evirme=\n\n"<<dag<<endl<<endl;
			hg=(kg*10);
			cout<<"Kilogram� Hektograma �evirme=\n\n"<<hg<<endl<<endl;
			lib=(kg*2.20);
			cout<<"Kilogram� Libreye �evirme=\n\n"<<lib<<endl<<endl;
			
			
		}
		else if(secen==2)
		{
			cout<<"D�n��t�rmek �stedi�iniz Hektogram De�erini Giriniz=\n\n";
			cin>>hg;
			kg=(hg*10);
			cout<<"Hektogram� KiloGrama �evirme=\n\n"<<kg<<endl<<endl;
			dag=(hg/10);
			cout<<"Hektogram� Dekagrama �evirme\n\n"<<dag<<endl<<endl;
			gr=(hg/100);
			cout<<"Hektogram� Grama �evirme=\n\n"<<gr<<endl<<endl;
			
			
			
		}
		else if(secen==3)
		{
			cout<<"D�n��t�rmek �stedi�iniz Dekagram De�erini Giriniz=\n\n";
			cin>>dag;
			kg=(dag*100);
			cout<<"Dekagram� KiloGrama �evirme=\n\n"<<kg<<endl<<endl;
			hg=(dag*10);
			cout<<"Dekagram� Hektograma �evirme=\n\n"<<hg<<endl<<endl;
			gr=(dag/10);
			cout<<"Dekagram� Grama �evirme\n\n"<<gr<<endl<<endl;
			
			
			
		}
		else if(secen==4)
		{
			cout<<"D�n��t�rmek istedi�iniz Gram De�erini Giriniz\n\n";
			cin>>g;
			kg=(g*1000);
			cout<<"Gram� Kilograma �evirme=\n\n"<<kg<<endl<<endl;
			hg=(g*100);
			cout<<"Gram� Hektograma �evirme=\n\n"<<hg<<endl<<endl;
			dag=(g*10);
			cout<<"Gram� Dekagrama �evirme\n\n"<<dag<<endl<<endl;
			lib=(gr/0.0022);
			cout<<"Gram� Libreye �evirme=\n\n"<<lib<<endl<<endl;
		}
		
		else if(secen==5)
		{
			cout<<"D�n��t�rmek �stedi�iniz Libre De�erini Giriniz=\n\n";
			cin>>lib;
			kg=(lib/2.20);
			cout<<"Libreyi KiloGrama �evirme=\n\n"<<kg<<endl<<endl;
			gr=(lib*0.0022);
			cout<<"Libreyi Grama �evirme=\n\n"<<gr<<endl<<endl;
		}
    }
    else if (secim==4)
	{
		cout<<"1-Salise �evirme\n2-Saniye �evirme\n3-Dakika �evirme\n4-Saat �evirme"<<endl<<endl;
		while(secenek<1 || secenek>4)
		{
			cout<<"l�tfen 1 ile 4 aras�ndaki se�eneklerden birisini se�iniz=\n";
			cin>>secenek;
		}
		if (secenek==1)
		{
			cout<<"D�n��t�rmek �stedi�iniz Salise De�erini Giriniz=\n\n";
			cin>>sl;
			sn=sl/60;
			cout<<"Saliseyi Saniyeye �evirme"<<sn<<endl<<endl;
			dk=sl/3600;
			cout<<"Saliseyi Dakikaya �evirme"<<dk<<endl<<endl;
			saat=sl/216000;
			cout<<"Saliseyi Saate �evirme"<<saat<<endl<<endl;
		}
		if (secenek==2)
		{
			cout<<"D�n��t�rmek �stedi�iniz Saniye De�erini Giriniz=\n\n";
			cin>>sn;
			sl=sn*60;
			cout<<"Saniyeyi Saliseye �evirme"<<sl<<endl<<endl;
			dk=sn/60;
			cout<<"Saniyeyi Dakikaya �evirme=\n\n"<<dk<<endl<<endl;
			saat=sn/3600;
			cout<<"Saniyeyi Saate �evirme=\n\n"<<saat<<endl<<endl;
			
		}
				if (secenek==3)
		{
			cout<<"D�n��t�rmek �stedi�iniz Dakika De�erini Giriniz=\n\n";
			cin>>dk;
			sl=dk*3600;
			cout<<"Dakikay� Saniyeye �evirme=\n\n"<<sl<<endl<<endl;
			sn=dk*60;
			cout<<"Dakikay� Saniyeye �evirme=\n\n"<<sn<<endl<<endl;
			saat=dk/60;
			cout<<"Dakikay� Saate �evirme=\n\n"<<saat<<endl<<endl;
			
		}
				if (secenek==4)
		{
			cout<<"D�n��t�rmek �stedi�iniz Saat De�erini Giriniz=\n\n";
			cin>>saat;
			sn=saat*3600;
			cout<<"Saati Saniyeye �evirme=\n\n"<<sn<<endl<<endl;
			dk=saat*60;
			cout<<"Saati Dakikaya �evirme=\n\n"<<dk<<endl<<endl;
			sl=saat*21600;
			cout<<"Saati Saliseye �evirme=\n\n"<<sl<<endl<<endl;
			
		}
		
		
    
	
	
	
	
	}
	else if(secim==5)
	{
		cout<<"1-Newton �evirme\n2-Milinewton �evirme\n3-Kilonewton D�n��t�rme";
		while(secenek<1 || secenek>3)
		{
			cout<<"l�tfen 1 ile 3 aras�ndaki se�eneklerden birisini se�iniz=\n";
			cin>>secenek;
		}
		if (secenek==1)
		{
			cout<<"D�n��t�rmek �stedi�iniz Newton De�erini Giriniz=\n\n";
			cin>>newt;
			knewt=newt/1000;
			cout<<"Newtonu Kilonewtona �evirme=\n\n"<<knewt<<endl<<endl;
			mnewt=newt*1000;
			cout<<"Newtonu Milinewtona �evirme=\n\n"<<mnewt<<endl<<endl;
			
			
		}
		else if (secenek==2)
		{
			cout<<"D�n��t�rmek �stedi�iniz Milinewton De�erini Giriniz=\n\n";
			cin>>mnewt;
			knewt=mnewt/1000000;
			cout<<"Milinewtonu Kilonewtona �evirme=\n\n"<<knewt<<endl<<endl;
			newt=mnewt/1000;
			cout<<"Milinewtonu Newtona �evirme=\n\n"<<newt<<endl<<endl;
			
			
		}
		else if (secenek==3)
		{
			cout<<"D�n��t�rmek �stedi�iniz Kilonewton De�erini Giriniz=\n\n";
			cin>>knewt;
			newt=knewt*1000;
			cout<<"Kilonewtonu Newtona �evirme=\n\n"<<newt<<endl<<endl;
			mnewt=knewt*1000000;
			cout<<"Newtonu Milinewtona �evirme=\n\n"<<mnewt<<endl<<endl;
			
			
		}
	}
	else if(secim==6)
    {
	
	
		cout<<"1-Kilowatt �evirme\n2-Watt �evirme\n3-MilliWatt\n4-Beygir G�c�"<<endl<<endl;
		while(secimler<1 || secimler>2);
	    {
		
	     	cout<<"l�tfen 1 ile 4 aras�ndaki se�eneklerden birisini se�iniz=\n\n";
			cin>>secimler;
	    }
		if (secimler==1)
	   {
			cout<<"D�n��t�rmek �stedi�iniz Kilowatt De�erini Giriniz=\n\n";
			cin>>kw;
			w=kw*1000;
			cout<<"Kilowatt� Watta �evirme=\n\n"<<w<<endl<<endl;
			mW=kw*1000000;
			cout<<"Kilowatt� MilliWatta �evirme=\n\n"<<mW<<endl<<endl;
			hp=kw*0.735498542977386;
			cout<<"Kilowatt� Beygir G�c�ne �evirme=\n\n"<<hp<<endl<<endl;
			
			
			
		}
		else if (secimler==2)
		{
			cout<<"D�n��t�rmek �stedi�iniz watt De�erini Giriniz=\n\n";
			cin>>w;
			kw=w/1000;
			cout<<"Watt� Kilowata �evirme=\n\n"<<kw<<endl<<endl;
			mW=w*1000;
			cout<<"Watt� MilliWatta �evirme=\n\n"<<mW<<endl<<endl;
			hp=w*735.498542977386;
			cout<<"Watt� Beygir G�c�ne �evirme=\n\n"<<hp<<endl<<endl;
			
			
		}
		else if (secimler==3)
		{
			cout<<"D�n��t�rmek istedi�iniz MilliWatt De�eriniz Giriniz=\n\n";
			cin>>mW;
			w=mW*1000;
			cout<<"MilliWatt� Watta �evirme=\n\n"<<w<<endl<<endl;
			kw=mW*1000000;
			cout<<"MilliWatt� Kilowatta �evirme=\n\n"<<kw<<endl<<endl;
			hp=mW*735498.542977386;
			cout<<"MilliWatt� Beygir G�c�ne �evirme=\n\n"<<hp<<endl<<endl;
			
		}
		else if (secimler==4)
		{
			cout<<"D�n��t�rmek �stedi�iniz Beygir G�c�n� Giriniz=\n\n";
			cin>>hp;
			kw=hp/0.735498542977386;
			cout<<"Beygir G�c�n� Kilowatta �evirme=\n\n"<<kw<<endl<<endl;
			w=hp/735.498542977386;
			cout<<"Beygir G�c�n� watta �evirme=\n\n"<<w<<endl<<endl;
			mW=hp/735498.542977386;
		    cout<<"Beygir G�c�n� MilliWatta �evirme=\n\n"<<mW<<endl<<endl;
		}
    }
}

